
var BaseClass = gb.classes.Class.extend({
    _callBack:null,
    _direction:null,
    view:null,
    name:null,
    ctor:function(name_){
        var self = this;
        self.view = $('#Panel_'+name_);
        self.name = name_;
        self.view.addClass('base-view');

    },
    askToAdd:function(data_){
        var self = this;

        // self.view.css('opacity',0);

        self.toAdd();

        if(data_){

            if(data_.type == 1){
                self.startAnimOut();
            }else if(data_.type == 2){
                self.startAnimIn();
            }
        }
        //console.log('askToAdd::',data_.type);

    },
    askToRemove:function(data_){
        var self = this;

        if(data_){

            self._callBack = data_.callBack;
            self._direction = data_.type;

            if(data_.type == 1){
                self.overAnimOut();
            }else if(data_.type == 2){
                self.overAnimIn();
            }


        }
        //console.log('askToRemove::',data_.type);
    },
    toAdd:function(){
        var self = this;
        self.view.css('display','block');
    },
    toRemove:function(){
        var self = this;
        self.view.css('display','none');
    },
    startAnimIn:function(){
        var self = this;
        
        //console.log('startAnimIn::',self.view.attr('id'));
    },
    startAnimOut:function(){
        var self = this;
        
        //console.log('startAnimOut::',self.view.attr('id'));
    },
    overAnimIn:function(){
        var self = this;
        self.overComplete();
        // if(self._callBack){
        //     self._callBack();
        // }
        
        
    },
    overAnimOut:function(){
        var self = this;
        self.overComplete();
        // if(self._callBack){
        //     self._callBack();
        // }
        
    },
    overComplete:function(){
        var self = this;
        self.toRemove();
        if(self._callBack){
            self._callBack();
        }

    }
});
/* -------------------------------------------base class end */

var SoundManage = {
    sound:null,
    isOn:true,
    name:'bg',
    init:function(){
        this.sound = {};
        this.sound['bg'] = $('#bg').get(0);
        
    },
    playSound:function(param_){
        this.sound[param_].play();  
        
    },
    stopSound:function(param_){
        
        this.sound[param_].pause();  
        // $('#media').get(0).pause();
    }
};

/* ------------------------------------------------SoundManage end */

var Loading = BaseClass.extend({
    _callback:null,
    _logingTxt:null,
    ctor:function(name_,callback_){
        var self = this;
        self._super(name_);
        self.view.css({'z-index':900,backgroundColor:'#000'});
        self._logingTxt = self.view.find('.loging-txt');
        self._callback = callback_;
    },
    askToAdd:function(data_){
        var self = this;
        // self._super();
    },
    askToRemove:function(data_){
        var self = this;
        //self._super();
        self.toRemove();
        self.view.empty();
        self.view.remove();
        
    },
    onProgress:function(val_){
        var self = this;
        self._logingTxt.html(val_+'%');
        
    },
    onComplete:function(val_){
        var self = this;
        self._logingTxt.html('100%');
        
        if(self._callback) self._callback();
        SoundManage.playSound('bg');

    }
});


/* ------------------------------------------------Loading end */

var IndexPanel = BaseClass.extend({
    _indexImg:null,
    _currentFrame:1,
    _timer:null,
    ctor:function(name_){
        var self = this;
        self._super(name_);
        self._indexImg = self.view.find('.index-img');
        self.view.bind(gb.events.TouchEnd,function(e){
            e.stopPropagation();
            e.preventDefault();
            app.nextPage();
            
        });
    },
    askToAdd:function(data_){
        var self = this;
        self._indexImg.css('display','none');
        self._currentFrame = 1;
        self._indexImg.attr('src','img/index/index-01.jpg');
        self._super(data_);
        

    },
    askToRemove:function(data_){
        var self = this;
        
        self._super(data_);
        

    },
    startAnimIn:function(){
        var self = this;
        self._super();
        self.nextAnim();
        
    },
    startAnimOut:function(){
        var self = this;
        self._super();
        self.nextAnim();
        
    },
    overAnimIn:function(){
        var self = this;
        self._super();

    },
    overAnimOut:function(){
        var self = this;
        self._super();
        //console.log('overAnimOut::',self.view.attr('id'));
        // self.overComplete();
    },
    nextAnim:function(){
        var self = this;
        self._indexImg.css('display','block');
        self._timer = setInterval(function(){
            self._currentFrame++;
            if(self._currentFrame >= 46){
                self._currentFrame = 45;
                clearInterval(self._currentFrame);
            }
            var str = '';
            if(self._currentFrame >= 1 && self._currentFrame <= 9){
                str = 'img/index/index-0'+self._currentFrame+'.jpg';
            }
            if(self._currentFrame >= 10 && self._currentFrame <= 99){
                str = 'img/index/index-'+self._currentFrame+'.jpg';
            }
            self._indexImg.attr('src',str);
        },90);


    }
});


var PagePanel2 = BaseClass.extend({
    _page2Btn:null,
    _page2Sprite1Btn:null,
    _page2Sprite2Btn:null,
    _page2Alert:null,
    _page2Alert1:null,
    _page2Alert2:null,
    _page2Sprite3:null,
    _page2Sprite4:null,
    _closeBtn:null,
    _page2OtherImg:null,
    _currentFrame:1,
    _timer:null,
    ctor:function(name_){
        var self = this;
        self._super(name_);

        self._page2Btn = self.view.find('.page2-btn');
        self._page2Sprite1Btn = self.view.find('.page2-sprite1-btn');
        self._page2Sprite2Btn = self.view.find('.page2-sprite2-btn');
        self._page2Alert = self.view.find('.page2-alert');
        self._page2Alert1 = self.view.find('.page2-alert1');
        self._page2Alert2 = self.view.find('.page2-alert2');
        self._page2Sprite3 = self.view.find('.page2-sprite3');
        self._page2Sprite4 = self.view.find('.page2-sprite4');
        self._closeBtn = self.view.find('.close-btn');

        self._page2OtherImg = self.view.find('.page2-other-img');

        self._page2Sprite1Btn.bind(gb.events.TouchEnd,{self:self},self.onBtnEvet1);
        self._page2Sprite2Btn.bind(gb.events.TouchEnd,{self:self},self.onBtnEvet2);
        self._closeBtn.bind(gb.events.TouchEnd,{self:self},self.onCloseBtnEvet);
        self._page2Btn.bind(gb.events.TouchEnd,{self:self},self.onBtnEvet);


    },
    askToAdd:function(data_){
        var self = this;
        TweenMax.set(self._page2Btn,{scaleX:0,scaleY:0});
        TweenMax.set(self._page2Alert,{scaleX:0,scaleY:0});
        self._currentFrame = 1;
        self._page2OtherImg.css('display','none');
        self._page2OtherImg.css('src','img/page2/page2-img'+self._currentFrame+'.png');
        self._super(data_);

    },
    askToRemove:function(data_){
        var self = this;
        self._super(data_);
        

    },
    startAnimIn:function(){
        var self = this;
        self._super();
        self.nextAnim();    
        
    },
    startAnimOut:function(){
        var self = this;
        self._super();
        self.nextAnim();
        //console.log('startAnimOut::',self.view.attr('id'));
    },
    overAnimIn:function(){
        var self = this;
        self._super();
        //console.log('overAnimIn::',self.view.attr('id'));
        // self.overComplete();
    },
    overAnimOut:function(){
        var self = this;
        self._super();
        //console.log('overAnimOut::',self.view.attr('id'));
        // self.overComplete();
    },
    nextAnim:function(){
        var self = this;
        self._page2OtherImg.css('display','block');
        // console.log(111);
        self._timer = setInterval(function(){

            self._currentFrame++;
            if(self._currentFrame >= 29){
                self._currentFrame = 28;
                clearInterval(self._timer);
                self._page2OtherImg.css('display','none');
            }
            self._page2OtherImg.attr('src','img/page2/page2-img'+self._currentFrame+'.png');
        },100);

    },
    onBtnEvet1:function(e){
        e.stopPropagation();
        e.preventDefault();
        var self = e.data.self;
        self._page2Alert1.css('display','block');
        self._page2Alert2.css('display','none');
        self._page2Sprite3.css('display','block');
        self._page2Sprite4.css('display','none');
        self.blockAlert();
    },
    onBtnEvet2:function(e){
        e.stopPropagation();
        e.preventDefault();
        var self = e.data.self;
        self._page2Alert1.css('display','none');
        self._page2Alert2.css('display','block');
        self._page2Sprite3.css('display','none');
        self._page2Sprite4.css('display','block');
        self.blockAlert();
    },
    blockAlert:function(){
        var self = this;
        TweenMax.to(self._page2Alert,1,{scaleX:1,scaleY:1,ease:Back.easeOut});
        
    },
    noneAlert:function(){
        var self = this;
        TweenMax.to(self._page2Alert,1,{scaleX:0,scaleY:0,ease:Back.easeIn});
        TweenMax.to(self._page2Btn,1,{scaleX:1,scaleY:1});
    },
    onCloseBtnEvet:function(e){
        e.stopPropagation();
        e.preventDefault();
        var self = e.data.self;
        self.noneAlert();
    },
    onBtnEvet:function(e){
        e.stopPropagation();
        e.preventDefault();
        app.nextPage();
    }
});

var PagePanel3 = BaseClass.extend({
    _page3Sprite1:null,
    _page3Sprite2:null,
    _page3Img:null,
    _page3Alert1:null,
    _page3Alert2:null,
    _currentFrame:1,
    _timer:null,
    ctor:function(name_){
        var self = this;
        self._super(name_);
        self._page3Sprite1 = self.view.find('.page3-sprite1');
        self._page3Sprite2 = self.view.find('.page3-sprite2');
        self._page3Alert1 = self.view.find('.page3-alert1');
        self._page3Alert2 = self.view.find('.page3-alert2');
        self._page3Img = self.view.find('.page3-img');


    },
    askToAdd:function(data_){
        var self = this;
        self._currentFrame = 1;
        self._page3Img.attr('src','img/page3-img'+self._currentFrame+'.png');
        self._page3Img.css('display','none');
        TweenMax.set(self._page3Alert1,{scaleX:0,scaleY:0});
        TweenMax.set(self._page3Alert2,{scaleX:0,scaleY:0});
        self._page3Sprite2.css('display','none');
        self._page3Sprite1.css('display','block');
        self._super(data_);
        
    },
    askToRemove:function(data_){
        var self = this;
        self._super(data_);
        

    },
    startAnimIn:function(){
        var self = this;
        self._super();
        self.nextAnim();
        //console.log('startAnimIn::',self.view.attr('id'));
    },
    startAnimOut:function(){
        var self = this;
        self._super();
        self.nextAnim();

        //console.log('startAnimOut::',self.view.attr('id'));
    },
    overAnimIn:function(){
        var self = this;
        self._super();
        //console.log('overAnimIn::',self.view.attr('id'));
        // self.overComplete();
    },
    overAnimOut:function(){
        var self = this;
        self._super();
        //console.log('overAnimOut::',self.view.attr('id'));
        // self.overComplete();
    },
    nextAnim:function(){
        var self = this;

        TweenMax.to(self._page3Alert1,1,{scaleX:1,scaleY:1,ease:Back.easeOut,onComplete:self.twoAnim});


    },
    twoAnim:function(){
        var self = app.getPanel('panel3');
        setTimeout(function(){
            TweenMax.to(self._page3Alert1,1,{scaleX:0,scaleY:0,ease:Back.easeIn,onComplete:function(){
                self.view.bind(gb.events.TouchEnd,function(e){
                    e.stopPropagation();
                    e.preventDefault();
                    self.threeAnim();
                    self.view.unbind();
                });
            }});            
        },2000);

        
    },
    threeAnim:function(){
        var self = app.getPanel('panel3');
        self._page3Img.css('display','block');
        self._page3Sprite1.css('display','none');
        self._timer = setInterval(function(){
            self._currentFrame++;
            if(self._currentFrame >= 9){
                self._currentFrame = 8;
                clearInterval(self._timer);
                self.fourAnim();
            }
            self._page3Img.attr('src','img/page3-img'+self._currentFrame+'.png');
        },100);
    },
    fourAnim:function(){
        var self = app.getPanel('panel3');
        self._page3Sprite2.css('display','block');
        TweenMax.to(self._page3Alert2,1,{scaleX:1,scaleY:1,ease:Back.easeOut});
        setTimeout(function(){
            app.nextPage();
        },3000);
    }
});


var PagePanel4 = BaseClass.extend({
    _page4Btn:null,
    ctor:function(name_){
        var self = this;
        self._super(name_);
        self._page4Btn = self.view.find('.page4-btn');

    },
    askToAdd:function(data_){
        var self = this;
        $('#txt').html(global.nums);
        self._page4Btn.addClass('scale-anim');
        self._super(data_);
        
    },
    askToRemove:function(data_){
        var self = this;
        self._super(data_);
        

    },
    startAnimIn:function(){
        var self = this;
        self._super();
        self.nextAnim();
        //console.log('startAnimIn::',self.view.attr('id'));
    },
    startAnimOut:function(){
        var self = this;
        self._super();
        self.nextAnim();

        //console.log('startAnimOut::',self.view.attr('id'));
    },
    overAnimIn:function(){
        var self = this;
        self._super();
        //console.log('overAnimIn::',self.view.attr('id'));
        // self.overComplete();
    },
    overAnimOut:function(){
        var self = this;
        self._super();
        //console.log('overAnimOut::',self.view.attr('id'));
        // self.overComplete();
    },
    nextAnim:function(){
        var self = this;

    }
});

/* ------------------------------------------------IndexPanel end */

var PublicPanel = gb.classes.Class.extend({
    ctor:function(){
        var self = this;

        // $(document).bind(gb.events.TouchEnd,function(e){
        //     if(e.changedTouches[0].pageX < document.documentElement.clientWidth/2){
        //         app.prevPage();
        //         // app.gotoPage(0);
        //     }else{
        //         app.nextPage();
        //         // app.gotoPage(1);
        //     }
        // });

        $('.music').bind(gb.events.TouchEnd,function(e){

            e.stopPropagation();
            e.preventDefault();
            if(app.isPlaying) return;

            if(SoundManage.isOn){
                SoundManage.isOn = false;
                $(this).find('img').attr('src','img/music-off.png');

                if(SoundManage.name != ''){
                    SoundManage.stopSound(SoundManage.name);
                }
                

            }else{

                SoundManage.isOn = true;
                
                $(this).find('img').attr('src','img/music-on.png');
                if(SoundManage.name != ''){
                    SoundManage.playSound(SoundManage.name);    
                }
                
            }
        });
        
    }
});

/* ------------------------------------------------初始化配置 start */

(function () {

    function initView() {
        
        gb.events.removeHandler(document, 'DOMContentLoaded', initView);


        initViewDom();
        

        app = {
            site:null,
            _getPanel:null,
            pageArr:['index','panel2','panel3','panel4'],
            panelFunArr:null,
            currentPage:'',
            currentId:-1,
            prevPageId:-1,
            totalNums:0,
            isHtml:false,
            isImage:false,
            isClick:false,
            isPlaying:false,
            isMove:false,
            init:function(){

                app._getPanel = [];
                this.panelFunArr = [];

                var loading = new Loading('loading',app.loadImageComplete);
                loading.askToAdd();
                // var publicpanel = new PublicPanel();
                app.setPanel('loading',loading);
                // app.setPanel('public',publicpanel);
                
                this.panelFunArr['index'] = IndexPanel;
                this.panelFunArr['panel2'] = PagePanel2;
                this.panelFunArr['panel3'] = PagePanel3;
                this.panelFunArr['panel4'] = PagePanel4;

                app.totalNums = app.pageArr.length;

                gb.ImageLoader.load({
                    images: wxapp.fileList,
                    thread: 1,
                    onUpdate: function(percent, counter, total) {
                        // var percent = Math.round( e.target.progress * 100);
                        loading.onProgress(percent);

                        // console.log(percent, counter, total);
                        
                    },
                    onComplete: function () {
                        loading.onComplete();
                    }
                });

            },
            setPanel:function(param_,class_){
                app._getPanel[param_] = class_;
            },
            getPanel:function(param_){
                return app._getPanel[param_];
            },
            loadHtmlComplete:function(){
                
                app.isHtml = true;
                app.loadComplete();
            },
            loadImageComplete:function(){

                app.isImage = true;
                app.loadComplete();
            },
            loadComplete:function(){
                
                if(app.isHtml && app.isImage){
                    app.site.interHtml();
                    var loading = app.getPanel('loading');
                    loading.askToRemove();

                    app.initPage();
                    
                }
            },            
            initPage:function(){

                var publicpanel = new PublicPanel();
                app.setPanel('public',publicpanel);

                this.nextPage();
                this.nextLoad();
            },
            nextPage:function(){
                app.prevPageId = app.currentId;
                app.currentId++;

                var len = app.pageArr.length;
                if(app.currentId >= len){
                    app.currentId = len - 1;
                    return;
                }
                app.currentPage = app.pageArr[app.currentId];

                app._direction = 2;

                if(app.prevPageId != -1){

                    var prevPanel = app.getPanel( app.pageArr[app.prevPageId] );
                    
                    if(!prevPanel){
                        app.panelCallBack();
                    }else{
                        prevPanel.askToRemove({type:2,callBack:app.panelCallBack});
                    }

                }else if(app.prevPageId == -1){

                    app.panelCallBack();
                }

            },
            prevPage:function(){
                app.prevPageId = app.currentId;
                app.currentId--;
                if(app.currentId == -1){
                    app.currentId = 0;
                    return;
                }

                app.currentPage = app.pageArr[app.currentId];
                app._direction = 1;

                if(app.prevPageId != -1){

                    var prevPanel = app.getPanel( app.pageArr[app.prevPageId] );
                    prevPanel.askToRemove({type:1,callBack:app.panelCallBack});

                }

            },
            gotoPage:function(param_){

                app.prevPageId = app.currentId;
                app.currentId = param_;

            
                app.currentPage = app.pageArr[app.currentId];

                if(app.prevPageId > app.currentId){

                    app._direction = 1;

                }else if(app.prevPageId < app.currentId){

                    app._direction = 2;

                }

                if(app.prevPageId != -1){

                    var prevPanel = app.getPanel( app.pageArr[app.prevPageId] );
                    prevPanel.askToRemove({type:1,callBack:app.panelCallBack});

                }
            },
            panelCallBack:function(){
                
                var panel = app.getPanel( app.pageArr[app.currentId] );
                
                if(!panel){

                    panel = new app.panelFunArr[ app.pageArr[app.currentId] ]( app.pageArr[app.currentId] );
                    app.setPanel(app.pageArr[app.currentId],panel);
                    
                }

                panel.askToAdd({type:app._direction});

            },
            nextLoad:function(){
                gb.ImageLoader.load({
                    images: wxapp.delayFileList,
                    thread: 1,
                    onUpdate: function(percent, counter, total) {
                        
                    },
                    onComplete: function () {
                        
                    }
                });
            }
        };
        
        app.site = new SitePanel(config,'minisite',app.loadHtmlComplete);
        SoundManage.init();
        app.init();



    };

    function initViewDom()
    {

        var DEFAULT_WIDTH = 640, // 页面的默认宽度
            ua = navigator.userAgent.toLowerCase(), // 根据 user agent 的信息获取浏览器信息
            deviceWidth = window.screen.width, // 设备的宽度
            devicePixelRatio = window.devicePixelRatio || 1, // 物理像素和设备独立像素的比例，默认为1
            targetDensitydpi;

        

        function onResize()
        {
            var domwidth = document.documentElement.clientWidth;
            var domheight = document.documentElement.clientHeight;
            var scale = Math.max(domwidth/640,domheight/1009);
            var width = 640*scale;
            var height = 1009*scale;

            TweenMax.set($('#minisite'),{scaleX:scale,scaleY:scale});
            $('#minisite').css({left:-(width-domwidth)/2,top:-(height-domheight)/2});
            // alert(domwidth+'--'+domheight);
        }

        $(window).resize(onResize);
        onResize();



        if(gb.browser.getUserAgent().android && gb.browser.browser() != 'Chrome' && gb.browser.browser() != 'UC' && gb.browser.browser() != 'Firefox'){
            targetDensitydpi = DEFAULT_WIDTH / deviceWidth * devicePixelRatio * 160;
            $('meta[name="viewport"]').attr('content', 'target-densitydpi=' + targetDensitydpi + ', width=device-width, user-scalable=no');
        }

    }

    gb.events.addHandler(document, 'DOMContentLoaded', initView);

})();

/* ------------------------------------------------初始化配置 end */

