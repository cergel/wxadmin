require.config({
    baseUrl: './js',
    paths: {
        zepto: 'libs/zepto',
        Deferred: 'libs/deferred',
        underscore: 'libs/underscore'
    },
    'shim': {
        zepto: {
            exports: '$'
        },
        underscore: {
            exports: '_'
        },
        Deferred: {
            deps: ['underscore'],
            exports: 'Deferred'
        }
    }
})([], function() {
    require([
            'zepto',
            'Deferred',
            'libs/cookie',
            'libs/base',
            'libs/xdomain'
        ],
        function(
            $,
            Deferred,
            Cookie,
            Base,
            Xdomain
        ) {
            var needLogin = true;
            console.log( _ )
            var pageDeferred = new _.Deferred();

            var $btn = $('#packet-btn');

            var iframe = document.createElement('iframe');
            iframe.src = 'http://mqq.wepiao.com/xlogin.html';
            // iframe.style.position = "absolute",
            // iframe.style.top = 0;
            iframe.style.display = 'none';
            document.body.appendChild(iframe);

            Xdomain.listen({
                 mqqopenid: function( data ){
                    console.log( data  );
                    renderButton( data )
                 }
            })

            var _newUrl1;
            var _newUrl2;
            function renderButton( data ){
                //var _originUrl = $btn.data('href');
                 _newUrl1 = encodeURI( 'http://b.wepiao.com/hongbao/index.html?pid=%DC%0B%05%86%0F%F2%D3%F8&channelid=28&chid=8020' + '&decode=1' + '&openid=' + data );
                 _newUrl2 = encodeURI('http://b.wepiao.com/hongbao/index.html?pid=r%11M%FE%3C%90%EA%23&channelid=28&chid=8020'+ '&decode=1' + '&openid=' + data );
                // alert(_newUrl)
                //$btn.attr('href', _newUrl );
                //$btn.removeClass( 'btnDisabled' );
                // alert(_newUrl1);
                // alert(_newUrl2) 
                var t = setInterval(function(){
                    time( _newUrl1, _newUrl2 )
                },1000)
            }
            //renderButton('test')

            /**
 * 图片预加载并显示进度
 * loading
 * IIFE
 */
var loading = (function(){
    $( '.icon-process' ).html( '0%' );
    var loadCount = 0,
        preLoadImgs = eventsConfig.preLoadImgs,
        len = preLoadImgs.length;
    if( len < 2 ){
        return;
    }
    $.each( preLoadImgs, function( index, item ){
        var fakeImg = new Image();
        fakeImg.src = item;
        fakeImg.onerror = function(){
            loadSuccess();
        }
        function loadSuccess(){
            var percent = parseInt( ( loadCount/len ).toFixed( 2 ) * 100 );
            loadCount ++;
            $( '.icon-process' ).html( percent + '%' );
            if( loadCount === len ){
                $( '.icon-process' ).html( 100 + '%' );
                setTimeout(function(){
                    $( '.mask_loading' ).css('opacity', 0 ).hide();
                }, 200);
            }
        }
        fakeImg.onload = loadSuccess;
    })
})();

//动画 -圆盘
var t=setInterval(function(){
    if($('.circle').hasClass('circle01')){
        $('.circle').removeClass('circle01');
        $('.circle').addClass('circle02');
    }
    else{
        $('.circle').removeClass('circle02');
        $('.circle').addClass('circle01');
    }

},1500)

//时间控制 -按钮变化
function time(_newUrl1, _newUrl2){
var _startDate='2015-08-13';
var _endDate='2015-08-21';
var startDate=Date.parse(_startDate.replace(/-/g, '/'));
var endDate=Date.parse(_endDate.replace(/-/g, '/'));

var myDate = new Date();
var currentTime = myDate.getTime();
var nowHour=myDate.getHours();
console.log(nowHour);
var date=myDate.getDate();
//alert(_newUrl1)
if(currentTime>=startDate && currentTime<endDate){
    if(date == 20){
        if(nowHour>=0 && nowHour <10){
           console.log('20-0-10点');
            $('.button').css('background-position','0 66.67%');
            $('.button').attr('href','javascript:void(0)');
            }
        if(nowHour>=10 && nowHour <12){
            $('.button').css('background-position','0 0');
            $('.button').attr('href',_newUrl1)
            }
        else if(nowHour>=12 && nowHour <15){
            console.log('20-12点-15点')
            $('.button').css('background-position','0 33.33%');
            $('.button').attr('href','javascript:void(0)');

        }
        else if(nowHour>=15 && nowHour <17){
            console.log('20-15点-17点');
             $('.button').css('background-position','0 0');
             $('.button').attr('href',_newUrl2);
        }
        else if(nowHour>=17){
            console.log('20-17点之后');
            $('.button').css('background-position','0 100%');
            $('.button').attr('href','javascript:void(0)');
        }
    }
    else{
        if(nowHour>=10 && nowHour <12){
            console.log('10点-12点')
            $('.button').css('background-position','0 0');
            $('.button').attr('href',_newUrl1)
        }
        else if(nowHour>=12 && nowHour <15){
            console.log('12点-15点')
            $('.button').css('background-position','0 33.33%');
            $('.button').attr('href','javascript:void(0)');

        }
        else if(nowHour>=15 && nowHour <17){
            console.log('15点-17点');
             $('.button').css('background-position','0 0');
             $('.button').attr('href',_newUrl2);
        }
        else{
            console.log('17点之后');
            $('.button').css('background-position','0 66.67%');
            $('.button').attr('href','javascript:void(0)');
        }
    }
   
}


}


//End

        }
        )
})




